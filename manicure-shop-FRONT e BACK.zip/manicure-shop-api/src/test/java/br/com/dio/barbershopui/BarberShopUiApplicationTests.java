package br.com.dio.barbershopui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarberShopUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
