package br.com.dio.barbershopui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarberShopUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarberShopUiApplication.class, args);
	}

}
