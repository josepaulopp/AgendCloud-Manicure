export const environment = {
    production: false,
    apiUrl: 'http://localhost:8080/' //após finalizar o backend, mudar para http://localhost:8080/
    //apiUrl: 'http://localhost:1080/'
}